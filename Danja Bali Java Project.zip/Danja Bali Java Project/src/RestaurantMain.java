
/** ***********************************************
 ***********  JAVA BarRestaurant   ***************
 ***********      Program          ***************
 ***********   BY Danja Bali       ***************
 ************************************************ */
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author DBali
 */
public class RestaurantMain {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        Restaurant menu = new Restaurant();

        System.out.print("\tEnter Form:\n");

        menu.Login();//Method call
        menu.start();//Method call
    }
}
