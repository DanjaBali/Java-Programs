
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author DBali
 */
public class BarRestaurant {

    private static ArrayList<Item> items = new ArrayList<Item>();  //ArrayList to keep all the items of the Table.

    private static ArrayList<Table> ListOfTable = new ArrayList<Table>();//ArrayList within BarRestaurant class to keep all the Tables being currently served

    public int NewTable(String Username) {//Method to Insert a New table
        Table nw = new Table();
        nw.setId(ListOfTable.size() + 1);
        nw.setUsername(Username);
        ListOfTable.add(nw);
        System.out.printf("\tTable %d was created \n", nw.getId());
        return nw.getId();
    }

    public void ShowItemsOnTable(int tableid) {//Method to show Items on table by ID

        Table ChosenTable = GetTableByID(tableid);
        if (ChosenTable != null) {
            ArrayList<Item> listItems = GetTableByID(tableid).getListOfItems();//ArrayList to get list of items in table by ID

            System.out.println("\tItems in table");
            for (int i = 0; i < listItems.size(); i++) { //for loop to get the size,means number of items in table
                System.out.printf("%d - %s - %.2f  \n", listItems.get(i).getId(), listItems.get(i).getName(), listItems.get(i).getPrice());//Show info about Item, ID, Names, Prices.
            }
        } else {
            System.out.printf("\tTable id not found");
        }

    }

    public void ShowItemsWithDiscountTable(int tableid) {// Method to show the Items With Discount in current Table
        Double amount = 0.0;
        Table selectedTable = GetTableByID(tableid);
        if (selectedTable != null) {
            ArrayList<Item> listItems = GetTableByID(tableid).getListOfItems();

            System.out.println("\tItems in table");
            for (int i = 0; i < listItems.size(); i++) {
                System.out.printf("%d - %s - %.2f  \n", listItems.get(i).getId(), listItems.get(i).getName(), listItems.get(i).getPrice());
                amount = amount + listItems.get(i).getPrice();
            }

            Double amountDiscount = amount - (amount * 0.1);// Calculate the discount
            System.out.printf("\tTotal Amount: %.2f \n", amount);
            System.out.printf("\tTotal Amount with discount: %.2f \n", amountDiscount);

        } else {
            System.out.printf("\tTable id not found");
        }

    }

    public void RemoveItemFromTable(int id, int tableid) {// public void Method to Remove item from table
        Item itm = GetItemByID(id);
        if (itm != null) {

            ArrayList<Item> listItems = GetTableByID(tableid).getListOfItems();
            GetTableByID(tableid).setTotalAmount(GetTableByID(tableid).getTotalAmount() - itm.getPrice());
            listItems.remove(itm);
            System.out.println("\tItem is removed");
        } else {
            System.out.printf("\tItem is not found");
        }
    }

    public Item GetItemByID(int id) {// public Method to get item by ID
        for (Item element : items) {
            if (element.getId() == id) {
                return element;
            }
        }
        return null;
    }

    public int GetItemIndexByID(int id) { //public Method to get item index or nr by ID

        for (int i = 0; i < items.size(); i++) {

            if (items.get(i).getId() == id) {
                return i;
            }
        }
        return 0;
    }

    public Table GetTableByID(int id) {//public returning  Method to get table by ID

        for (Table element : ListOfTable) {
            if (element.getId() == id) {
                return element;
            }
        }
        return null;
    }

    public int GetTablesForUsername(String username) {//public returning  Method to get tables for username

        int tableCount = 0;
        for (Table element : ListOfTable) {
            if (element.getUsername() == username) {
                tableCount = tableCount + 1;

            }
        }
        return tableCount;
    }

    public double GetTotalAmountTablesByUsername(String username) {//public returning  Method to get total amount of tables for username

        int tableCount = 0;
        double totalAmount = 0.0;
        for (Table element : ListOfTable) {
            if (element.getUsername() == username) {
                tableCount = tableCount + 1;
                totalAmount = totalAmount + element.getTotalAmount();

            }
        }
        return totalAmount;
    }

    public int GetTotalNumberOfItemsProcessedByUsername(String username) {//public returning  Method to get total number of items processed by Username

        int itemProcecessed = 0;

        for (Table element : ListOfTable) {
            if (element.getUsername() == username) {
                itemProcecessed = itemProcecessed + element.getListOfItems().size();

            }
        }
        return itemProcecessed;
    }

    public double GetTotalAmountsOfItemsProcessedForUsername(String username) { //public returning value Method to print overall table Nr

        double totalAmount = 0.0;
        for (Table elements : ListOfTable) {
            if (elements.getUsername() == username) {

                for (Item itm : elements.getListOfItems()) {
                    totalAmount = totalAmount + itm.getPrice();
                }

            }
        }
        return totalAmount;
    }

    public void InsertItemInTable(int tableid, int itemid) {//public void Method to insert items in table by their ID 
        Item selectedItem = GetItemByID(itemid);
        if (selectedItem != null) {

            GetTableByID(tableid).AddItemsOnList(selectedItem);
            GetTableByID(tableid).setTotalAmount(GetTableByID(tableid).getTotalAmount() + selectedItem.getPrice());
            System.out.printf("%s was added on table %d \n", selectedItem.getName(), tableid);
        } else {
            System.out.printf("\tItem was not found");
        }
    }

    public void OverallTableNr(int id, String Username) {//public void Method to print overall table Nr
        Table tb = new Table();
        for (Table element : ListOfTable) {
            if (element.getId() == id) {
                tb.setUsername(Username);
                System.out.printf("\tNumber of table %d created by %s \n", tb.getUsername());
            }
        }
    }

    public void OrderItemsFomMenu() { // public void for Food items with certain name,ID, price and list nr

        items.add(new Item("TOST", 1, 5.00, 1));
        items.add(new Item("FREE RUNN EGG", 2, 5.00, 1));
        items.add(new Item("HOLLANDAISE", 3, 4.95, 1));
        items.add(new Item("TURKEY SAUSAGE", 4, 5.00, 1));
        items.add(new Item("HASH BROWN", 5, 4.00, 1));
        items.add(new Item("BACON or BANGERS", 6, 5.00, 1));

        items.add(new Item("CAESAR SALAD", 7, 3.95, 2));
        items.add(new Item("PATAO SALAD", 8, 6.5, 2));
        items.add(new Item("ONION RINGS", 9, 12, 2));
        items.add(new Item("GARDEN SALAD", 10, 12, 2));
        items.add(new Item("CREAMY MUSHROOM", 11, 10, 2));
        items.add(new Item("CHICKEN & RICE", 12, 8, 2));

        items.add(new Item("BANANA MUFFIN", 13, 4.00, 2));
        items.add(new Item("DOUBLE CHOCOLATE MUFFIN", 14, 4.00, 2));
        items.add(new Item("ICE CREAM", 15, 3.00, 2));
        items.add(new Item("DUDOK APPLE PIE", 16, 4.00, 2));
        items.add(new Item("CHOCOLATE TRUFLLE", 17, 4.00, 2));
        items.add(new Item("CUPCAKE", 18, 4.00, 2));

        items.add(new Item("FRESH MIN TEA WITH HONEY", 19, 2.00, 2));
        items.add(new Item("COLD MILK", 20, 2.00, 2));
        items.add(new Item("FRESH ORANGE JUICE ", 21, 2.00, 2));
        items.add(new Item("SMOOTHIE ", 22, 3.25, 2));
        items.add(new Item("BOTTLED BEER ", 23, 3.45, 2));
        items.add(new Item("PELLEGRINO ", 24, 3.00, 2));
    }

    public void BarMenu() {//call BarMenu Method

        System.out.print("------ Items ------ \n");//Print all the Bar items with each ID,Name, and Price
        for (int j = 0; j < items.size(); j++) {
            System.out.printf("\t%d - %s - $%.2f \n", items.get(j).getId(), items.get(j).getName(), items.get(j).getPrice());
        }
    }
}
