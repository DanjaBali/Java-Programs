
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author DBali
 */
public class StoreData {

    public static ArrayList<User> logInUsers = new ArrayList<>();
    public static ArrayList<User> currentManager = new ArrayList<>();

}
