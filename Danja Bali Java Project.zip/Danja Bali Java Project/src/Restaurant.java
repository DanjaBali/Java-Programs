
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author DBali
 */
public class Restaurant {

    private boolean exit = false;
    private int option;
    Scanner input = new Scanner(System.in);

    private BarRestaurant bar = null;
    private User currentUser;
    private EmployeeData main = new EmployeeData();
    public static ArrayList<User> accounts = new ArrayList<>();
    private Waiter w = new Waiter();
    private static int ChosenTable = 1;

    public void start() {
        bar = new BarRestaurant();
        bar.OrderItemsFomMenu();
        do {
            printMenu();
            Choice();

            System.out.println();
        } while (!exit);
    }

    public void Login() {//public void Method to log in as Manager Or Waiter
        System.out.print("\tLogin as: \n"
                + "\t1- Manager \n "
                + "\t2- Waiter ");
        int type = input.nextInt();
        if (type == 1) {
            login();
        } else {
            loginAsWaiter();
        }
    }

    private void printMenu() { //private void Method to print the menu of choice for user
        System.out.print("\t - Menu of Choice \n"
                + "\t1 - New table \n"
                + "\t2 - Insert item in table \n"
                + "\t3 - Remove item from table \n"
                + "\t4 - Modify item in table \n"
                + "\t5 - Print information for current table\n"
                + "\t6 - Print information for table with a certain ID\n"
                + "\t7 - Apply discount to table with 10%\n"
                + "\t8 - Overall number of tables for the waiter with a certain username\n"
                + "\t9 - Total amount of all tables processed by the waiter with a certain username \n"
                + "\t10 - Total number of all items processed by the waiter with a certain username  \n"
                + "\t11 - Total amount of all items of the current day \n"
                + "\t12 - Switch program from one waiter to another waiter\n"
                + "\t13 - Switch program from Waiter to Manager and vice-versa\n"
                + "\t14 - Exit\n"
                + "\tSelect an option: ");

        option = input.nextInt(); //input option
    }

    private void Choice() {
        if (option == 1) {
            bar = new BarRestaurant();
            ChosenTable = bar.NewTable(currentUser.getUsername());
        } else if (option == 2) {
            NewItem();
        } else if (option == 3) {
            removeItem();
        } else if (option == 4) {
            ModifyItemInTable();
        } else if (option == 5) {
            bar = new BarRestaurant();
            bar.ShowItemsOnTable(ChosenTable);
        } else if (option == 6) {
            PrintSpecificTable();
        } else if (option == 7) {
            applyDiscountToTable();
        } else if (option == 8) {
            PrintOverallNrOfTablesProcessedByWaiterID();
        } else if (option == 9) {
            PrintTotalAmountOfTablesForWaiterID();
        } else if (option == 10) {
            PrintTotalNrOfItemsProcessedByWaiterID();
        } else if (option == 11) {
            TotalAmountOfItemPerDay();
        } else if (option == 12) {
            SwitchToWaiter();
        } else if (option == 13) {
            SwitchToManager();
        } else if (option == 14) {
            exit();
        } else {
            System.out.println("\tInvalid Choice; Insert a number from 1 to 14");
        }

    }

    private void login() {//private void method to login and authenticate the defined Manager with some certain parameters
        boolean isAuthenticated = false;

        input.nextLine();
        System.out.println("\tLOG IN");
        do {
            System.out.println();
            System.out.println("\tEnter Username: ");
            String username = input.nextLine();
            System.out.println("\tEnter Password: ");
            String password = input.nextLine();
            currentUser = main.AuthenticateUser(username, password);

            if (currentUser != null) {
                System.out.println("\tAccess Granted, Welcome!");
                currentUser = main.getAccount(username);
                isAuthenticated = true;
            } else {
                System.out.println("\tInvalid Username & Password\n");
                isAuthenticated = false;
            }
        } while (!isAuthenticated);

    }

    private void loginAsWaiter() {//private void method to login as waiter
        boolean isAuthenticated = false;

        input.nextLine();
        System.out.println("\tLOG IN");
        do {
            System.out.println();
            System.out.println("\tEnter Username: ");
            String username = input.nextLine();
            System.out.println("\tEnter Password: ");
            String password = input.nextLine();
            currentUser = main.AuthenticateUser(username, password);

            if (currentUser != null) {
                if (currentUser.getUserType() == 2) { //user type 2 are waiters  defined list with certain parameters
                    System.out.println("\tAccess Granted, Welcome!");
                    currentUser = main.getAccount(username);
                    isAuthenticated = true;
                } else {
                    System.out.println("\tUser logged in is not waiter\n");
                    isAuthenticated = false;
                }
            } else {
                System.out.println("\tInvalid Username & Password\n");
                isAuthenticated = false;
            }
        } while (!isAuthenticated);

    }

    private void NewItem() {//private void Method to add new Items

        System.out.println("------- Restaurant Menu!-------\n");
        bar = new BarRestaurant();
        bar.BarMenu();
        System.out.println("\tEnter ID of food \n");
        int ID = input.nextInt();
        bar.InsertItemInTable(ChosenTable, ID);

    }

    private void removeItem() { //private void Method to remove Items
        bar = new BarRestaurant();
        bar.ShowItemsOnTable(ChosenTable);
        System.out.println("\tEnter ID item to delete \n");
        int ID = input.nextInt();
        bar.RemoveItemFromTable(ID, ChosenTable);
        System.out.println("\tShow remaining items in table\n");
        bar.ShowItemsOnTable(ChosenTable);

    }

    private void ModifyItemInTable() {
        bar = new BarRestaurant();
        bar.ShowItemsOnTable(ChosenTable);
        System.out.println("\tEnter the item ID  to modify items in table\n");
        int ID = input.nextInt();
        bar.RemoveItemFromTable(ID, ChosenTable);

        System.out.println("\tEnter the item ID  to add items in table \n");
        bar.BarMenu();
        int idAdd = input.nextInt();
        bar.InsertItemInTable(ChosenTable, idAdd);
        bar.ShowItemsOnTable(ChosenTable);

    }

    private void PrintSpecificTable() {//Private Void Method to Print Specific Table
        System.out.println("\tInsert Table id \n");
        int ID = input.nextInt();
        bar = new BarRestaurant();
        bar.ShowItemsOnTable(ID);
    }

    private void applyDiscountToTable() {//Private Void Method to apply 10% discount to table
        System.out.println("\tApplying 10% discount to table");

        bar.ShowItemsWithDiscountTable(ChosenTable);
    }

    private void applyDiscount() {//
        System.out.println("\tApplying 10% discount for loyal customer");
        System.out.print("\tEnter normal discount rate for CompanyCustomer: ");
        double discount = input.nextDouble();
        System.out.print("\tEnter Company discount rate for CompnayCustomer: ");
        double CompanyDiscount = input.nextDouble();
        main.applyDiscounts(10, discount, CompanyDiscount);
    }

    private void PrintTotalAmountOfTablesForWaiterID() {//Private Void Method to print total amount Of tables 'For' waiter ID
        if (currentUser.getUserType() == 1) {
            System.out.println("\tSelect the waiter to print tables \n");
            ArrayList<User> waiters = main.PrintWaiterList();

            for (int i = 0; i < waiters.size(); i++) {
                System.out.printf("%d - %s \n", waiters.get(i).getID(), waiters.get(i).getName());
            }

            int ID = input.nextInt();
            User selectedWaiter = main.GetUserByID(ID);
            bar = new BarRestaurant();
            double tablesAmount = bar.GetTotalAmountTablesByUsername(selectedWaiter.getUsername());

            System.out.printf("\tAmount processed by waiter %s = %.2f  \n", selectedWaiter.getUsername(), tablesAmount);
        } else {
            System.out.println("\tPermision denied. Please login as manager \n");
        }
    }

    private void PrintOverallNrOfTablesProcessedByWaiterID() {//Private Void Method to print Overall numbr Of tables processed 'By' Waiter an ID
        if (currentUser.getUserType() == 1) {
            System.out.println("\tSelect the waiter to print tables \n");
            ArrayList<User> waiters = main.PrintWaiterList();

            for (int i = 0; i < waiters.size(); i++) {
                System.out.printf("%d - %s \n", waiters.get(i).getID(), waiters.get(i).getName());
            }

            int ID = input.nextInt();
            User selectedWaiter = main.GetUserByID(ID);
            bar = new BarRestaurant();
            int tables = bar.GetTablesForUsername(selectedWaiter.getUsername());

            System.out.printf("\tWaiter %s has  %d tables \n", selectedWaiter.getUsername(), tables);
        } else {
            System.out.println("\tPermision denied. Please login as manager \n");
        }
    }

    private void PrintTotalNrOfItemsProcessedByWaiterID() {//Private Void Method to print total number of all 'items' processed by the waiter with an ID

        if (currentUser.getUserType() == 1) {
            System.out.println("\tSelect the waiter to print tables \n");
            ArrayList<User> waiters = main.PrintWaiterList();

            for (int i = 0; i < waiters.size(); i++) {
                System.out.printf("%d - %s \n", waiters.get(i).getID(), waiters.get(i).getName());
            }

            int ID = input.nextInt();
            User selectedWaiter = main.GetUserByID(ID);
            bar = new BarRestaurant();
            int items = bar.GetTotalNumberOfItemsProcessedByUsername(selectedWaiter.getUsername());

            System.out.printf("\tWaiter %s has processed  %d items in all tables \n", selectedWaiter.getUsername(), items);
        } else {
            System.out.println("\tPermision denied. Please login as manager \n");
        }
    }

    private void TotalAmountOfItemPerDay() { //Private Void Method to print total amount of all 'items' of the current day 
        if (currentUser.getUserType() == 1) {
            System.out.println("\tSelect the waiter to print tables \n");
            ArrayList<User> waiters = main.PrintWaiterList();

            for (int i = 0; i < waiters.size(); i++) {
                System.out.printf("%d - %s \n", waiters.get(i).getID(), waiters.get(i).getName());
            }

            int ID = input.nextInt();
            User selectedWaiter = main.GetUserByID(ID);
            bar = new BarRestaurant();
            double itemsAmount = bar.GetTotalAmountsOfItemsProcessedForUsername(selectedWaiter.getUsername());

            System.out.printf("\tWaiter %s total items amount processed =  %.2f  \n", selectedWaiter.getUsername(), itemsAmount);
        } else {
            System.out.println("\tPermision denied. Please login as manager \n");
        }
    }

    private void SwitchToWaiter() {

        if (currentUser.getUserType() == 1) {// Private Void Method to 'Switch program fom Manager' authenicated with 1  To waiter by 2.
            System.out.println("\tLogged In as Manager");
            System.out.println("\tSwitch to Waiter");
            loginAsWaiter();
        } else if (currentUser.getUserType() == 2) {
            System.out.println("\tLogged In as " + currentUser.getName());
            System.out.println("\tLogin as other waiter");
            loginAsWaiter();
        }

    }

    private void SwitchToManager() {//Private Void Method Method to 'Switch program fom waiter' authenicated with 2  To Manager by 1.
        if (currentUser.getUserType() == 1) {
            System.out.println("\tLogged In as Manager");
            System.out.println("\tSwitch to Waiter");
        } else {
            System.out.println("\tLogged In as Waiter");
            System.out.println("\tSwitch to Manager");
        }

        login();//login call
    }

    private void exit() { //Private Void Method to Exit the Program
        System.out.println("\tProgram Exit");
        exit = true;
    }

}
