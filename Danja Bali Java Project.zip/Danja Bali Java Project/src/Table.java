import java.util.ArrayList;
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author DBali
 */
public class Table {

    private int ID;
    private double OrderNetAmount;
    private double OrderTotalAmount;
    private double VAT;
    private ArrayList<Item> listOfItems;
    private Date DateAndTimeofOrder;
    private String Username;
    private String BarRestaurantAddress;
    private String nameOfReceptionist;

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public Table() {

        super();
        listOfItems = new ArrayList<>();

    }

    public Table(final double netAmount, final double totalAmount, final double vAT, final ArrayList<Item> listOfItems,
            final Date dateAndTimeOfPurchase, final String addressOfTheRestaurant, final String nameOfCashier) {

        super();

        this.OrderNetAmount = netAmount;
        this.OrderTotalAmount = totalAmount;
        VAT = vAT;
        this.listOfItems = listOfItems;
        this.DateAndTimeofOrder = dateAndTimeOfPurchase;
        this.BarRestaurantAddress = addressOfTheRestaurant;
        this.nameOfReceptionist = nameOfCashier;
    }

    public void AddItemsOnList(Item addItems) {
        if (listOfItems == null) {
            listOfItems = new ArrayList<>();
        } else {
            listOfItems.add(addItems);

        }

    }

    public double getNetAmount() {
        return OrderNetAmount;
    }

    public double getTotalAmount() {
        return OrderTotalAmount;
    }

    public double getVAT() {
        return VAT;
    }

    public ArrayList<Item> getListOfItems() {
        return listOfItems;
    }

    public Date getDateAndTimeOfPurchase() {
        return DateAndTimeofOrder;
    }

    public String getAddressOfTheBarOrRestaurant() {
        return BarRestaurantAddress;
    }

    public String getNameOfReceptionist() {
        return nameOfReceptionist;
    }

    public void setNetAmount(final double OrderNetAmount) {
        this.OrderNetAmount = OrderNetAmount;
    }

    public void setTotalAmount(final double OrderTotalAmount) {
        this.OrderTotalAmount = OrderTotalAmount;
    }

    public void setVAT(final double vAT) {
        VAT = vAT;
    }

    public void setListOfItems(final ArrayList<Item> listOfItems) {
        this.listOfItems = listOfItems;
    }

    public void setDateAndTimeOfPurchase(final Date dateAndTimeOfPurchase) {
        this.DateAndTimeofOrder = dateAndTimeOfPurchase;
    }

    public void setAddressOfTheBarOrRestaurant(final String addressOfBarOrRestaurant) {
        this.BarRestaurantAddress = addressOfBarOrRestaurant;
    }

    public void setNameOfReceptionist(final String nameOfReceptionist) {
        this.nameOfReceptionist = nameOfReceptionist;
    }

    public int getId() {
        return ID;
    }

    public void setId(int ID) {
        this.ID = ID;
    }

    public void setAddressOfTheBarRestaurant(String BarRestaurantAddress) {
        this.BarRestaurantAddress = BarRestaurantAddress;
    }
}
