
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author DBali
 */
public class EmployeeData implements Serializable {//Serialization to convert an Object to stream and save it as file for later usage

    public static ArrayList<User> accounts = new ArrayList<>();//ArrayList to store user accounts
    public static ArrayList<Customer> customers = new ArrayList<>(); //ArrayList for customers

    public EmployeeData() {
        if (getAccount("Danja") == null) {
            User Danja = new Manager("Danja", "Bali", "danja", "999999", "Kodra e Diellit", "069345333", "123", 1);
            accounts.add(Danja);
        }
        if (getWaiterAccount("Waiter1") == null) {
            User Waiter1 = new Waiter("Amelia", "Johnson", "amelia", "123456", "Kodra e Diellit", "069345333", "123", 2);
            accounts.add(Waiter1);
        }
        if (getWaiterAccount("Waiter2") == null) {
            User Waiter2 = new Waiter("Liam", "Parker", "liam", "1234567", "Kodra e Diellit", "069345333", "123", 2);
            accounts.add(Waiter2);
        }
        if (getWaiterAccount("Waiter3") == null) {
            User Waiter3 = new Waiter("Emma", "Brown", " emma", "1234568", "Kodra e Diellit", "069345333", "123", 2);
            accounts.add(Waiter3);
        }
        if (getWaiterAccount("Waiter4") == null) {
            User Waiter4 = new Waiter("Emi", "Brown", "emi", "123456##", "Kodra e Diellit", "069345333", "123", 2);
            accounts.add(Waiter4);
        }
        if (getWaiterAccount("Waiter5") == null) {
            User Waiter5 = new Waiter("Addison", "Parker", "addison", "123456@@", "Kodra e Diellit", "069345333", "123", 2);
            accounts.add(Waiter5);
        }
    }

    public User GetUserByID(int id) {//Method to get user by ID, with one parameter

        for (User cust : accounts) {
            if (cust.getID() == id) {
                return cust;
            }
        }
        return null;
    }

    public ArrayList<User> PrintWaiterList() { // Print Waiter List from arraylist <User> created above.
        ArrayList<User> list = new ArrayList<>();
        for (User customer : accounts) {
            if (customer.getUserType() == 2) {
                list.add(customer);
            }
        }
        return list;
    }

    public Customer getCustomer(int id) {//Method get costumer with 1 parameter 
        try {
            for (Customer cust : customers) {
                if (cust.getID() == id) {
                    return cust;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public User getAccount(String username) {//Method get Account with 1 parameter 
        for (User acc : accounts) {
            if (acc.getUsername().equals(username)) {
                return acc;
            }
        }
        return null;
    }

    public User getWaiterAccount(String username) {//Method getWaiterAccount with 1 parameters 
        for (User Waiteracc : accounts) {
            if (Waiteracc.getUsername().equals(username)) {

            }
        }
        return null;
    }

    public void addCustomer(Customer customer) { //Method to add Customer
        customers.add(customer);
    }

    public User AuthenticateUser(String username, String password) {//Method for Authenticating User, with 2 parameters 

        for (User u : accounts) {

            if (u.getUsername().equals(username) && u.getPassword().equals(password)) {
                return u;
            }

        }
        return null;

    }

    public User getUserById(int id) {//Method to get user by ID, with 1 parameters 
        for (User user : accounts) {
            if (user.getID() == id) {
                return user;
            }
        }
        return null;
    }

    public static ArrayList<String> getNames(ArrayList<Customer> customers) {//Get names of costumers from arraylist <Customer> created above.
        ArrayList<String> nameList = new ArrayList<>();
        for (Customer customer : customers) {
            nameList.add(customer.getName());
        }
        return nameList;
    }

    public void applyDiscounts(double loyalDiscount, double discount, double companyDiscount) {//public void Method to apply certain Discounts, with 3 parameters 
        for (Customer customer : customers) {
            if (customer instanceof LoyalCustomer) {
                ((LoyalCustomer) customer).setDiscount(discount);
            } else if (customer instanceof CompanyCustomer) {
                ((CompanyCustomer) customer).setDiscount(discount);
                ((CompanyCustomer) customer).setCompanyDiscount(companyDiscount);
            }
        }
    }
}
